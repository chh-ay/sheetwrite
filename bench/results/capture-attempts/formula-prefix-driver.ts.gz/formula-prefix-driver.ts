// Investigation only. Expose the frozen workload factory in memory, not on disk.
import { plugin } from "bun";
import { createHash } from "node:crypto";
import { pathToFileURL } from "node:url";

const frozen = "<worktrees>/bench-060-formula-final";
const sourcePath = `${frozen}/bench/src/formula-bench.ts`;
if (process.argv.includes("--worker")) {
  plugin({
    name: "diagnostic-workload-access",
    setup(build) {
      build.onLoad({ filter: /\/formula-bench\.ts$/ }, async ({ path }) => ({
        contents: `${await Bun.file(path).text()}\nexport { formulaWorkloads };\n`,
        loader: "ts",
      }));
    },
  });
  const root = process.env.SHEETWRITE_BENCH_ENGINE_ROOT ?? frozen;
  const packageName = process.env.SHEETWRITE_BENCH_ENGINE === "full" ? "formulas" : "wasm";
  const engine = await import(pathToFileURL(`${root}/packages/${packageName}/loader-node.mjs`).href);
  const core = await import(pathToFileURL(`${frozen}/packages/core/dist/index.js`).href);
  const harness = await import(pathToFileURL(sourcePath).href);
  await core.initSheetwrite(undefined, engine);
  await engine.load();
  const rows = [];
  const stop = packageName === "formulas" ? "text-lookup-many" : "text-lookup-many-sorted";
  for (const workload of harness.formulaWorkloads(false)) {
    rows.push(harness.collectFixture(workload.id, workload.size, workload.factory, 5));
    if (workload.id === stop) break;
  }
  if (rows.at(-1)?.id !== stop) throw new Error(`Missing stop workload ${stop}`);
  console.log(JSON.stringify(rows));
} else {
  const blocks = Number(process.env.FORMULA_BLOCKS ?? 10);
  const rows = [];
  for (const kind of ["default", "full"]) {
    for (let block = 0; block < blocks; block++) {
      for (const side of ["baseline", "candidate", "candidate", "baseline"]) {
        const child = Bun.spawnSync(["bun", import.meta.path, "--worker"], {
          env: {
            ...process.env,
            SHEETWRITE_BENCH_ENGINE: kind,
            SHEETWRITE_BENCH_ENGINE_ROOT: side === "baseline" ? "<worktrees>/bench-060-data-base" : undefined,
          },
          stdout: "pipe", stderr: "pipe",
        });
        if (child.exitCode !== 0) throw new Error(child.stderr.toString());
        const workloads = JSON.parse(child.stdout.toString());
        rows.push({ kind, block, side, workloads });
        console.error(kind, block, side, workloads.length);
      }
    }
  }
  await Bun.write(new URL(`formula-prefix-${blocks}.json`, import.meta.url), JSON.stringify({
    diagnosticOnly: true,
    sourceSha256: createHash("sha256").update(await Bun.file(sourcePath).bytes()).digest("hex"),
    blocks, order: ["baseline", "candidate", "candidate", "baseline"], rows,
  }, null, 2));
}
